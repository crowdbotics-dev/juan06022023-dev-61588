from django.apps import AppConfig


class ArticlesConfig(AppConfig):
    name = "modules.django_articles.articles"
    verbose_name = "Articles"
